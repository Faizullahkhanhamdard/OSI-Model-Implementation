public class OSIModel {

    String _message,el, Ip, macAdd, sourceId, portAdd;
    public OSIModel (String message) {
        this._message = message;
    }

    public OSIModel application (String el) {
        this._message += el;
        return this;
    }

    
    public OSIModel presentation () {
        this._message += "";
        return this;
    }

    
    public OSIModel session (String sourceId) {
        this._message += sourceId;
        return this;
    }

    public OSIModel transport (String portAdd) {
        this._message += portAdd;
        return this;
    }

    public OSIModel network (String ip) {
        this._message += ip;
        return this;
    }

    public OSIModel datalink(String macAdd) {
        this._message += macAdd;
        return this;
    }

    public String physical() {
        this._message = this._message + this.el
        + this.presentation() 
        + this.sourceId + this.portAdd 
        + this.Ip + this.macAdd ;
        
        return this._message;
    }

}