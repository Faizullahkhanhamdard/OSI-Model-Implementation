
public class Main {
    public static void main(String[] args) {

        OSIModel os = new OSIModel("Faiz ");

       System.out.println( 
        os.application("Khan ")
        .presentation()
        .session("2-")
        .transport("2x.44.6x-")
        .network("192.168.11.254-")
        .datalink("mc-23-45-df-")
        .physical()
        );

    }
}